
## Laravel Article API

#Created by Sayed akhtar

#Get All Article
GET -/article

#Get One Article 

GET -/article/{id}

#Create New Article

POST -/article/create

#Update Article

PUT -/article/edit/{id}

#Delete an Article

DELETE -/article/{id}