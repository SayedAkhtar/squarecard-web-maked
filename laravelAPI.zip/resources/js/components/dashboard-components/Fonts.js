import React, { Component } from 'react'

export class Fonts extends Component {
  render() {
    return (
      <div>
        Fonts
      </div>
    )
  }
}

export default Fonts
