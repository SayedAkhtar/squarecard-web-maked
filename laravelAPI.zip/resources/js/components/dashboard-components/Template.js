import React, { Component } from 'react'

export class Template extends Component {
  render() {
    return (
      <div>
        Template
      </div>
    )
  }
}

export default Template
