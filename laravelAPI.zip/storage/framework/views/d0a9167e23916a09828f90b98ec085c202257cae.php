<?php $__env->startSection('content'); ?>
    
    <div class="login-container">
        <h1 class="login-container-heading">sign up</h1>
        <form method="POST" action="<?php echo e(route('login')); ?>" >
            <?php echo csrf_field(); ?>
            <?php echo e(route('login')); ?>

            <div class="form-group">
                <input type="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" id="email" placeholder="email" value="<?php echo e(old('email')); ?>">
            </div>
            <div class="form-group">
                <input type="tel" class="form-control" id="mobile" placeholder="mobile number" pattern="[0-9]{3-14}">
            </div>
            <div class="form-group">
                <input type="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" id="password" placeholder="password" required>
            </div>
            <!-- <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div> -->
            <div class="login-container__social">
                <h6 class="login-container__social--heading">Already a member?</h6>
                <div class="login-container__social--buttons">
                    <a href="#">
                        <img src="img/buttons/001-search.svg" alt="">
                    </a>
                     <a href="#">
                        <img src="img/buttons/002-facebook.svg" alt="">
                    </a>
                </div>
            </div>
            <button type="submit" class="btn login-container__social--submit">Continue</button>
                <?php if(Route::has('password.request')): ?>
                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('Forgot Your Password?')); ?>

                    </a>
                <?php endif; ?>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views/builder/pages/login.blade.php */ ?>