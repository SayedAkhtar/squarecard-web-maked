<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 col-sm-12 main-container">
        <div class="container-fluid">
                <div class="d-flex align-items-center justify-content-sm-between mb-1">
                        <div class="action__button">
                            <div class="action__button--left">
                                <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard" class="mr-3"><img src="<?php echo e(asset('img/back.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                                <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard"><img src="<?php echo e(asset('img/home.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                            </div>
                        </div>
                    <h3 class="dashboard--heading text-uppercase mt-4">Templates </h3>
                    <div class="dashboard__head-buttons">
                        <a href="#" class="btn btn-secondary">Share 
                            <img src="<?php echo e(asset("img/share.png")); ?>" alt="" class="img-responsive" height="16px">
                        </a>
                        <a href="#" class="btn btn-secondary">Help ?</a> 
                    </div>
                </div>

            <!-- Card Container -->
            <div class="row">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Groom card -->
                <div class="col-md-3 col-sm-12" >
                    <div class="card bg-dark text-white" <?php if($user->template_name == $item->template_name): ?>
                            style="box-shadow: 2px 2px 10px rgba(94,190,206,0.7);"
                        <?php endif; ?>>
                        <a href="<?php echo e(url()->current()); ?>/" style="color:inherit;">
                        <img src="<?php echo e(asset('img/templates/'.$item->template_name.'/index.jpg')); ?>" class="card-img" alt="...">
                        
                        </a>
                    </div>
                    <h5 class="card-text text-center mt-1 text-capitalize"><?php echo e(__($item->template_name )); ?></h5>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- Card container ends -->
        </div>
        
    </div>
   
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views//builder/pages/templates/index.blade.php */ ?>