<?php


?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-7 col-sm-12 main-container view-family">
        <div class="container">
            <h3 class="view-family--heading text-uppercase mt-4">All Story</h3>
            <div class="row mt-4">
                <div class="col-12">
                    <h5 class="text-uppercase">Team Groom</h5>
                    <div class="container">
                        <div class="row">
                                <div class="owl-carousel owl-theme">
                                    <?php
                                        $length = count($groom);
                                    ?>
                                    <?php for($i = 0; $i < $length; $i++): ?>
                                    <?php
                                        $data = $groom[$i]
                                    ?>
                                    <a href="<?php echo e(url()->current()); ?>/edit/<?php echo e($data->id); ?>" class="no-link-style">
                                    <div class="item">
                                        <?php echo $__env->make('builder.pages.family.card',['data' => $data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    </a>
                                    <?php endfor; ?>    
                                </div>
                        </div>                            
                    </div>
                </div>
            </div>

            
            <div class="row mt-4">
                <div class="col-12">
                    <h5 class="text-uppercase">Team Bride</h5>
                    <div class="container">
                        <div class="row">
                            <div class="owl-carousel owl-theme">
                                    <?php
                                    $length = count($bride);
                                ?>
                                <?php for($i = 0; $i < $length; $i++): ?>
                                <?php
                                    $data = $bride[$i]
                                ?>
                                <a href="<?php echo e(url()->current()); ?>/edit/<?php echo e($data->id); ?>" class="no-link-style">
                                <div class="item">
                                    <?php echo $__env->make('builder.pages.family.card',['data' => $data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                </a>
                                <?php endfor; ?> 
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
            
            <div class="row mt-4">
                <div class="col-12">
                    
                    <div class="container mx-auto">
                        <div class="row add-button">
                          <a href="<?php echo e(url()->current()); ?>/add" class="no-link-style">
                            <i class="fas fa-plus"></i>
                          </a>
                        </div> 
                    </div>
                </div>
            </div>

            
        </div>
    </div>
    <div class="col-md-5 col-sm-12 web-view"></div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views/builder/pages/family.blade.php */ ?>