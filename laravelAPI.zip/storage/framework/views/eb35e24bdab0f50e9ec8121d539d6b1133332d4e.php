<?php $__env->startSection('content'); ?>
    
    <div class="login-container">
        <h1 class="login-container-heading">Login</h1>
        <form action="#">
            <div class="form-group">
                <input type="email" class="form-control" id="email" placeholder="email">
            </div>
            <div class="form-group">
                <input type="tel" class="form-control" id="mobile" placeholder="mobile number" pattern="[0-9]{3-14}">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" id="password" placeholder="password">
            </div>
            <!-- <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div> -->
            <div class="login-container__social">
                <h6 class="login-container__social--heading">Not a member? <a href="<?php echo e(url()->current()); ?>/sign-up">Sign Up</a></h6>
                <div class="login-container__social--buttons">
                    <a href="#">
                        <img src="img/buttons/001-search.svg" alt="">
                    </a>
                     <a href="#">
                        <img src="img/buttons/002-facebook.svg" alt="">
                    </a>
                </div>
            </div>
            <button type="submit" class="btn login-container__social--submit">Continue</button>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views//builder/layout/login.blade.php */ ?>