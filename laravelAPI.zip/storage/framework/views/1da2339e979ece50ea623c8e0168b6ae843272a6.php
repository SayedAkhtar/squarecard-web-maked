<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-7 col-sm-12 main-container add-story">
        <!-- <h5 class="mb-2">Bride</h5> -->
        <div class="container add-story__container">
                <div class="col-md-12">
                <div class="d-flex align-items-center justify-content-sm-between mb-3">
                        <div class="action__button">
                            <div class="action__button--left">
                                <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard/story" class="mr-3"><img src="<?php echo e(asset('img/back.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                                <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard"><img src="<?php echo e(asset('img/home.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                            </div>
                        </div>
                    <h3 class="dashboard--heading text-uppercase mt-4">Stroy | Add</h3>
                    <div class="dashboard__head-buttons">
                        <a href="#" class="btn btn-secondary">Share 
                            <img src="<?php echo e(asset("img/share.png")); ?>" alt="" class="img-responsive" height="16px">
                        </a>
                        <a href="#" class="btn btn-secondary">Help ?</a> 
                    </div>
                </div>
            
                    <div class="row">
                    <div class="col-md-5 col-sm-12">
                            <h5 class="mb-2">Groom</h5>
                            <div class="card bg-light text-white" id="imageInputBtn">
                                <img src="<?php echo e(asset("img/capture.png")); ?>" class="card-img" alt="..." id="userImage">
                                <div class="card-img-overlay">
                                    
                                </div>
                            </div>
                        </div>
                   
                <div class="col-md-7">
                <form class="" method="POST" action="<?php echo e(url()->current()); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                    <input type="text" class="form-control" id="formGroupExampleInput" name="story_title" placeholder="Story Title" >
                    </div>
                    <div class="form-group">
                    <input type="date" class="form-control" id="formGroupExampleInput2" placeholder="DD/MM/YYYY" name="story_start_date" >
                    </div>
                    <div class="form-group">
                    <input type="text" class="form-control" id="formGroupExampleInput3" placeholder="Place" name="story_place" >
                    </div>
                    <div class="form-group">
                    <textarea type="text" class="form-control" id="formGroupExampleInput2" placeholder="Describe Your Moment" name="about" rows="5"></textarea>
                    </div>
                    <input type="file" name="image" id="imageInput" hidden>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-cancel">Cancel <span class="text-uppercase"> x </span></button>
                        <button type="submit" class="btn btn-submit">Submit <span class="text-uppercase"> > </span></button>
                    </div>
                </form>
            </div>    
            </div>
             </div>
    </div>
    </div>
    <div class="col-md-5 col-sm-12 web-view">
            <a href="<?php echo e(env('APP_URL')); ?>/<?php echo e($user->UserURL); ?>" class="btn btn-cancel px-4" target="_blank">VIEW LIVE <img src="<?php echo e(asset("img/internet.png")); ?>" alt="" class="img-responsive ml-2" height="24px"></a>
            <div class="preview-container d-flex justify-content-center align-items-center h-100" style="position:relative;">
                <img src="<?php echo e(asset('img/mobile-frame.png')); ?>" alt="" class="" style="height:540px; width:289px;">
            <iframe src="<?php echo e(env('APP_URL')); ?>/<?php echo e($user->UserURL); ?>/story" frameborder="0" style="    width: calc(414px /1.75);height: calc(685px /1.75);border:none; top:120px; position:absolute; overflow-x:hidden;" scrolling="no" ></iframe>
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views/builder/pages/story/add-story.blade.php */ ?>