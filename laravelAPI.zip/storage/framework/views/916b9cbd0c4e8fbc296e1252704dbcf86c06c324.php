<?php
$length  = count($story);

?>


<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-7 col-sm-12 main-container view-story">
        <div class="container">
        <div class="d-flex align-items-center justify-content-sm-between mb-3">
                <div class="action__button">
                    <div class="action__button--left">
                        <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard" class="mr-3"><img src="<?php echo e(asset('img/back.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                        <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard"><img src="<?php echo e(asset('img/home.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                    </div>
                </div>
            <h3 class="dashboard--heading text-uppercase mt-4">Story</h3>
            <div class="dashboard__head-buttons">
                <a href="#" class="btn btn-secondary">Share 
                    <img src="<?php echo e(asset("img/share.png")); ?>" alt="" class="img-responsive" height="16px">
                </a>
                <a href="#" class="btn btn-secondary">Help ?</a> 
            </div>
        </div>
                <div class="row mt-5 mx-auto">
                <?php
                    while ($length){
                        
                ?>
                
                <div class="card mb-3" style="min-height: 200px; width:100%;">
                    <div class="row no-gutters">
                        <div class="col-md-4">
                        <img src="<?php echo e(asset('images/'.$story[$length-1]->story_image)); ?>" class="card-img" alt="...">
                        </div>
                        <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($story[$length-1]->story_title); ?></h5>
                            <p class="card-text"><?php echo e($story[$length-1]->story_date); ?></p>
                            <p class="card-text"><?php echo e($story[$length-1]->story_venue); ?></p>
                            <p class="card-text"><small class="text-muted"><?php echo e($story[$length-1]->story_short_description); ?></small></p>
                            <a href="<?php echo e(url()->current()); ?>/edit/<?php echo e($story[$length-1]->id); ?>" class="btn btn-submit">Edit</a>
                            <form action="<?php echo e(url()->current()); ?>/delete" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <input type="text" value="<?php echo e($story[$length-1]->id); ?>" name="id" hidden>
                                <input type="submit" class="btn btn-submit" value="Remove"></a>
                            </form>
                            
                        </div>
                        </div>
                    </div>
                </div>
                <?php $length--; } ?>
                <div class="card mb-3 d-flex justify-content-center align-items-center view-story__add-button" style="min-height: 200px; width:100%;">
                    <div class="row no-gutters">
                        
                        <div class="col-md-12 ">
                        <div class="card-body d-flex justify-content-center align-items-center">
                            <a href="<?php echo e(url()->current()); ?>/add" class="h2 no-link-style " >
                                <i class="fas fa-plus"></i>
                            </a>
                        </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <div class="col-md-5 col-sm-12 web-view">
            <a href="<?php echo e(env('APP_URL')); ?>/<?php echo e($user->UserURL); ?>" class="btn btn-cancel px-4" target="_blank">VIEW LIVE <img src="<?php echo e(asset("img/internet.png")); ?>" alt="" class="img-responsive ml-2" height="24px"></a>
            <div class="preview-container d-flex justify-content-center align-items-center h-100" style="position:relative;">
                <img src="<?php echo e(asset('img/mobile-frame.png')); ?>" alt="" class="" style="height:540px; width:289px;">
            <iframe src="<?php echo e(env('APP_URL')); ?>/<?php echo e($user->UserURL); ?>#story" frameborder="0" style="    width: calc(414px /1.75);height: calc(685px /1.75);border:none; top:120px; position:absolute; overflow-x:hidden;" scrolling="no" ></iframe>
            </div>
        </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views//builder/pages/story/view-story.blade.php */ ?>