<?php
$length  = count($story);

?>


<?php $__env->startSection('content'); ?>


<div class="row">
        <div class="col-md-7 col-sm-12 main-container view-story">
            <div class="container">
                <h3 class="view-story--heading text-uppercase mt-4">All Story</h3>
                <div class="d-flex mt-5">
                <?php
                    while ($length){
                        
                ?>
                <div class="card mr-3" style="width: 18rem;">
                    <img src="..." class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($story[$length-1]->story_title); ?></h5>
                        <p class="card-text"><?php echo e($story[$length-1]->story_short_description); ?></p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
                </div>
                <?php $length--; } ?>
                </div>
            </div>
        </div>
        <div class="col-md-5 col-sm-12 web-view"></div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views//builder/pages/view-story.blade.php */ ?>