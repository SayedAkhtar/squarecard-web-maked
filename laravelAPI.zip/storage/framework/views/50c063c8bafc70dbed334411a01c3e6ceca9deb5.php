<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-7 col-sm-12 main-container evevnt-details">
        <!-- <h5 class="mb-2">Bride</h5> -->
        <div class="container event-details__container">
            <div class="col-md-8">
                    <h3 class="text-uppercase mt-4">Basic Event Details</h3>
                <form class="">
                    <div class="form-group">
                        <input type="text" class="form-control" id="formGroupExampleInput" name="event-name" placeholder="Event Name">
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <input type="text" class="form-control" id="formGroupExampleInput" name="groom-name" placeholder="Groom Name">
                            </div>
                        </div>
                         <div class="col-6">
                            <div class="form-group">
                                <input type="text" class="form-control" id="formGroupExampleInput" name="bride-name" placeholder="Bride Name">
                            </div>
                        </div>      
                    </div>
                    <div class="form-group">
                        <input type="date" class="form-control" id="formGroupExampleInput2" placeholder="DD/MM/YYYY" name="event-date">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="formGroupExampleInput3" placeholder="Event Venue" name="event-place">
                    </div>
                    <div class="form-group">
                        <textarea type="text" class="form-control" id="formGroupExampleInput2" placeholder="Describe Your Event" name="about" rows="5"></textarea>
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-cancel">Cancel <span class="text-uppercase"> x </span></button>
                        <button type="submit" class="btn btn-submit">Submit <span class="text-uppercase"> > </span></button>
                    </div>
                </form>
             </div>
    </div>
    </div>
    <div class="col-md-5 col-sm-12 web-view"></div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views//builder/pages/events-details.blade.php */ ?>