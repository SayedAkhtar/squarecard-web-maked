<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-7 col-sm-12 about-main-container main-container">
        <div class="container-fluid">
                <div class="d-flex align-items-center justify-content-sm-between mb-3">
                        <div class="action__button">
                            <div class="action__button--left">
                                <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard" class="mr-3"><img src="<?php echo e(asset('img/back.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                                <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard"><img src="<?php echo e(asset('img/home.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                            </div>
                        </div>
                    <h3 class="dashboard--heading text-uppercase mt-4">Wedding Register</h3>
                    <div class="dashboard__head-buttons">
                        <a href="#" class="btn btn-secondary">Share 
                            <img src="<?php echo e(asset("img/share.png")); ?>" alt="" class="img-responsive" height="16px">
                        </a>
                        <a href="#" class="btn btn-secondary">Help ?</a> 
                    </div>
                </div>

            <!-- Card Container -->
            <div class="row about-card">
                    <div class="col-md-6 col-sm-12 mt-2">
                        
                        <div class="card" style="width: 18rem;">
                            <a href="<?php echo e(url()->current()); ?>/add"> <img src="<?php echo e(asset('img/capture.png')); ?>" class="card-img-top" alt="add new">
                            <div class="card-body">
                                <a href="<?php echo e(url()->current()); ?>/add" class="btn btn-submit text-center mx-auto px-3 py-2" style="opacity:0;" >Add</a>
                            </div>
                            </a>
                        </div>
                    </div>
                <!-- Groom card -->
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <div class="col-md-6 col-sm-12 mt-2">
                        
                        <div class="card" style="width: 18rem;">
                            <a href="<?php echo e($item->register_url); ?>" target="_blank"><img src="<?php echo e(asset("images/".$item->register_image)); ?>" class="card-img-top" alt="<?php echo e($item->register_name); ?>"></a>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($item->register_name); ?></h5>
                                
                                <a href="<?php echo e(url()->current()); ?>/edit/<?php echo e($item->id); ?>" class="btn btn-submit ml-0" >Edit</a>
                                <form action="<?php echo e(url()->current()); ?>/delete" method="post" style="display:inline;s">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" value="<?php echo e($item->id); ?>" name="id" hidden>
                                    <button type="submit" class="btn btn-danger" style="border-radius:100px;">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- Card container ends -->
        </div>
        
    </div>
    <div class="col-md-5 col-sm-12 web-view"></div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views//builder/pages/registry/index.blade.php */ ?>