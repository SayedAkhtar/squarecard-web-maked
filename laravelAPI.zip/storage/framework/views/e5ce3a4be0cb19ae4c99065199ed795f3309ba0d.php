<?php


?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-7 col-sm-12 main-container view-family">
        <div class="container">
            <div class="d-flex align-items-center justify-content-sm-between mb-3">
                    <div class="action__button">
                        <div class="action__button--left">
                            <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard" class="mr-3"><img src="<?php echo e(asset('img/back.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                            <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard"><img src="<?php echo e(asset('img/home.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                        </div>
                    </div>
                <h3 class="dashboard--heading text-uppercase mt-4">All Story</h3>
                <div class="dashboard__head-buttons">
                    <a href="#" class="btn btn-secondary">Share 
                        <img src="<?php echo e(asset("img/share.png")); ?>" alt="" class="img-responsive" height="16px">
                    </a>
                    <a href="#" class="btn btn-secondary">Help ?</a> 
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-12">
                    <h5 class="text-uppercase">Team Groom</h5>
                    <div class="container">
                        <div class="row">
                                <div class="owl-carousel owl-theme">
                                    <?php
                                        $length = count($groom);
                                    ?>
                                    <?php for($i = 0; $i < $length; $i++): ?>
                                    <?php
                                        $data = $groom[$i]
                                    ?>
                                    
                                    <div class="item">
                                        <?php echo $__env->make('builder.pages.family.card',['data' => $data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    
                                    <?php endfor; ?>    
                                </div>
                        </div>                            
                    </div>
                </div>
            </div>

            
            <div class="row mt-4">
                <div class="col-12">
                    <h5 class="text-uppercase">Team Bride</h5>
                    <div class="container">
                        <div class="row">
                            <div class="owl-carousel owl-theme">
                                    <?php
                                    $length = count($bride);
                                ?>
                                <?php for($i = 0; $i < $length; $i++): ?>
                                <?php
                                    $data = $bride[$i]
                                ?>
                                
                                <div class="item">
                                    <?php echo $__env->make('builder.pages.family.card',['data' => $data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                
                                <?php endfor; ?> 
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
            
            <div class="row mt-4">
                <div class="col-12">
                    
                    <div class="container mx-auto">
                        <div class="row add-button">
                          <a href="<?php echo e(url()->current()); ?>/add" class="no-link-style">
                            <i class="fas fa-plus"></i>
                          </a>
                        </div> 
                    </div>
                </div>
            </div>

            
        </div>
    </div>
    <div class="col-md-5 col-sm-12 web-view">
        <a href="<?php echo e(env('APP_URL')); ?>/<?php echo e($user->UserURL); ?>" class="btn btn-cancel px-4" target="_blank">VIEW LIVE <img src="<?php echo e(asset("img/internet.png")); ?>" alt="" class="img-responsive ml-2" height="24px"></a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views/builder/pages/family/index.blade.php */ ?>