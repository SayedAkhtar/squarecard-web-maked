<?php 
    
?>


<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-7 col-sm-12 main-container add-story">
        <!-- <h5 class="mb-2">Bride</h5> -->
        <div class="container add-story__container">
            <div class="col-md-7">
                    <h3 class="text-uppercase mt-4">Add Story</h3>
                <form class="" enctype="multipart/form-data" method="POST" action="<?php echo e(Url("/")); ?>/builder/dashboard/schedule/add">
                    <div class="form-group">
                        <input type="text" class="form-control" id="formGroupExampleInput" name="story-title" placeholder="Event Title">
                    </div>
                    <div class="form-group d-flex">
                        <div class="col-6 p-0">
                        <input type="date" class="form-control" id="formGroupExampleInput2" placeholder="DD/MM/YYYY" name="event-start-date">
                        </div>
                        <div class="col-6 p-0">
                        <input type="time" class="form-control" id="formGroupExampleInput3" placeholder="DD/MM/YYYY" name="event-start-time">
                        </div>
                    </div>
                    <div class="form-group d-flex">
                        <div class="col-6 p-0">
                        <input type="date" class="form-control" id="formGroupExampleInput4" placeholder="DD/MM/YYYY" name="event-end-date">
                        </div>
                        <div class="col-6 p-0">
                        <input type="time" class="form-control" id="formGroupExampleInput5" placeholder="DD/MM/YYYY" name="event-end-time">
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="formGroupExampleInput6" placeholder="Place" name="event-venue">
                    </div>
                    <div class="form-group">
                        <textarea type="text" class="form-control" id="formGroupExampleInput7" placeholder="Event Short Description" rows="3" name="event-short-description"></textarea>
                    </div>
                    <div class="form-group">
                        <textarea type="text" class="form-control" id="formGroupExampleInput8" placeholder="Event Long Description" rows="5" name="event-long-description"></textarea>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="formGroupExampleInput9" placeholder="Event Note" name="event-note">
                    </div>
                    <div class="form-group">
                        <input type="file" class="form-control" id="formGroupExampleInput10" placeholder="Event Image" name="event-image">
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-cancel">Cancel <span class="text-uppercase"> x </span></button>
                        <button type="submit" class="btn btn-submit">Submit <span class="text-uppercase"> > </span></button>
                    </div>
                </form>
             </div>
    </div>
    </div>
    <div class="col-md-5 col-sm-12 web-view"></div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views//builder/pages/add-schedule.blade.php */ ?>