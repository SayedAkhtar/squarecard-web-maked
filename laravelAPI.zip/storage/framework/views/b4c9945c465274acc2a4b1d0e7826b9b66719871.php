<?php echo e($slot); ?>


<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php */ ?>