<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-7 col-sm-12 about-main-container main-container">
        <div class="container-fluid">
            <h3 class="about-page--heading text-uppercase mt-4">about couple</h3>

            <!-- Card Container -->
            <div class="row about-card">

                <!-- Groom card -->
                <div class="col-md-6 col-sm-12">
                    <h5 class="mb-2">Groom</h5>
                    <div class="card bg-dark text-white">
                        <a href="<?php echo e(url()->current()); ?>/edit" style="color:inherit;">
                        <img src="<?php echo e(asset("img/groom.jpg")); ?>" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <h2 class="card-title">Groom Name</h2>
                            <p class="card-text">Profession</p>
                            <p class="card-text">29 years old</p>
                        </div>
                        </a>
                    </div>
                </div>

                <!-- Bride card -->
                <div class="col-md-6 col-sm-12">
                    <h5 class="mb-2">Bride</h5>
                    <div class="card bg-dark text-light">
                        <a href="<?php echo e(url()->current()); ?>/edit" style="color:inherit;">
                        <img src="<?php echo e(asset("img/bride.jpg")); ?>" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <h2 class="card-title">Bride Name</h2>
                            <p class="card-text">Profession</p>
                            <p class="card-text">26 years old</p>
                        </div>
                        </a>
                    </div>
                </div>
            </div>
            <!-- Card container ends -->
        </div>
        
    </div>
    <div class="col-md-5 col-sm-12 web-view"></div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views//builder/pages/about-part.blade.php */ ?>