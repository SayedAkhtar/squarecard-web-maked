<?php $__env->startSection('iframe'); ?>
    

<div class="web-view__buttons">   
        <a href="<?php echo e(env('APP_URL')); ?>/<?php echo e($user->UserURL); ?>" class="btn btn-cancel px-4 mt-0" target="_blank">VIEW LIVE <img src="<?php echo e(asset("img/internet.png")); ?>" alt="" class="img-responsive ml-2" height="24px"></a>
    </div>
    <div class="web-view__container">
        <div class="web-view__container--preview">
            <div class="web-preview">
                <img src="<?php echo e(asset('img/browser-window.png')); ?>" alt="" class="web-preview--img">
                
            </div>
            <div class="mobile-preview">
                <img src="<?php echo e(asset('img/mobile-frame.png')); ?>" alt="" class="mobile-preview--img">
                
            </div>
        </div>
        <div class="web-view__container--preview-select">
            <ul class="btn btn-cancel web-view__container--preview-select-ul">
                <li id="web-preview"><i class="fas fa-desktop"></i> Web</li>
                <li id="mobile-preview"><i class="fas fa-mobile-alt"></i> Mobile</li>
            </ul>
        </div>
</div>


<?php $__env->stopSection(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views/builder/layout/iframe.blade.php */ ?>