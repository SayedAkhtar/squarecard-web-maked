<?php $__env->startSection('content'); ?>
    
    <div class="login-container">
        <h1 class="login-container-heading">One more step ...</h1>
        <form action="<?php echo e(url()->current()); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" class="form-control" id="groom-name" placeholder="Groom's Name" name="groom_name">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" id="bride-name" placeholder="Bride's Name" name="bride_name">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" id="event-name" placeholder="Event name" name="event_name">
            </div>
            <div class="form-group">
                <select name="userurl" id="option" class="form-control" 
                style="border-left: none;
                       border-right: none;
                       border-top: none;
                       border-radius: 0px;
                       border-width: 2px;">
                    <option value="" selected> Chose Your URL </option>
                </select>
                
            </div>
            <?php if($errors->all()): ?>    
                <div class="form-group">
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e($item); ?>

                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            
           <div class="p-2 m-5"></div>
            <button type="submit" class="btn login-container__social--submit">Continue</button>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            var url = `<?php echo e(env('APP_URL')); ?>/builder/information/checkurl`;
            var x,y;
           $("#groom-name").on('keyup', function(e){
              x = $(this)[0].value;
           })
           $("#bride-name").on('keyup', function(e){
              y = $(this)[0].value;
           })
           $("#option").click(function(){           
            $.ajax({
                headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                        'Access-Control-Allow-Origin': '*' 
                    },
                data: { groom_name: x, bride_name: y}, 
                url: url,
                method: 'post',
                success: function(data){
                    data.forEach(element => {
                        $( "#option" ).append( `<option value="${element}">${element}</option>" `);
                        // console.log(element);
                    });
                }
            });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views//builder/pages/basic-required.blade.php */ ?>