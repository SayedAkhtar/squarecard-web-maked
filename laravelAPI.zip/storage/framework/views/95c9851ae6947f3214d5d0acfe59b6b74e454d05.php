<?php 
    
?>


<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-7 col-sm-12 main-container add-story">
        <!-- <h5 class="mb-2">Bride</h5> -->
        <div class="container add-story__container">
                <div class="d-flex align-items-center justify-content-sm-between mb-3">
                        <div class="action__button">
                            <div class="action__button--left">
                                <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard/schedule" class="mr-3"><img src="<?php echo e(asset('img/back.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                                <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard"><img src="<?php echo e(asset('img/home.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                            </div>
                        </div>
                    <h3 class="dashboard--heading text-uppercase mt-4">Schedule |edit</h3>
                    <div class="dashboard__head-buttons">
                        <a href="#" class="btn btn-secondary">Share 
                            <img src="<?php echo e(asset("img/share.png")); ?>" alt="" class="img-responsive" height="16px">
                        </a>
                        <a href="#" class="btn btn-secondary">Help ?</a> 
                    </div>
                </div>
            <div class="col-md-7">
                    
                <form class="" enctype="multipart/form-data" method="POST" action="<?php echo e(url()->current()); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" class="form-control" id="formGroupExampleInput" name="event_name" placeholder="Event Title"
                        value="<?php echo e($data->event_name); ?>" required
                        >
                    </div>
                    <div class="form-group d-flex">
                        <div class="col-6 p-0">
                        <input type="text" class="form-control date" id="formGroupExampleInput2" placeholder="DD/MM/YYYY" name="event_start_date"
                        value="<?php echo e($data->event_start_data); ?>" required
                        >
                        </div>
                        <div class="col-6 p-0">
                        <input type="time" class="form-control" id="formGroupExampleInput3" placeholder="DD/MM/YYYY" name="event_start_time"
                        value="<?php echo e($data->event_start_time); ?>" required
                        >
                        </div>
                    </div>
                    <div class="form-group d-flex">
                        <div class="col-6 p-0">
                        <input type="text" class="form-control date" id="formGroupExampleInput4" placeholder="DD/MM/YYYY" name="event_end_date"
                        value="<?php echo e($data->event_end_date); ?>"
                        >
                        </div>
                        <div class="col-6 p-0">
                        <input type="time" class="form-control" id="formGroupExampleInput5" placeholder="DD/MM/YYYY" name="event_end_time"
                        value="<?php echo e($data->event_end_time); ?>"
                        >
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="formGroupExampleInput6" placeholder="Place" name="event_venue"
                        value="<?php echo e($data->event_venue); ?>" required
                        >
                    </div>
                    <div class="form-group">
                        <small>MAX: 180 Characters</small>
                        <textarea type="text" class="form-control" id="formGroupExampleInput7" placeholder="Event Short Description" rows="3" name="event_short_description" maxlength="180"><?php echo e($data->event_short_description); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                    <input type="file" class="form-control" id="formGroupExampleInput10" placeholder="Event Image" name="image" >
                    </div>
                    <div class="form-group">
                            <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-cancel">Cancel <span class="text-uppercase"> x </span></button>
                        <button type="submit" class="btn btn-submit">Submit <span class="text-uppercase"> > </span></button>
                    </div>
                </form>
             </div>
    </div>
    </div>
    <div class="col-md-5 col-sm-12 web-view"></div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views//builder/pages/schedule/edit-schedule.blade.php */ ?>