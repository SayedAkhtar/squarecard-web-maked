<?php
$length = count($data);
$i = $length ;
?>

<?php $__env->startSection('content'); ?>
 
<div class="row">
    <div class="col-md-7 col-sm-12 main-container photo-album">
        <div class="container">
            <h3 class="view-family--heading text-uppercase mt-4">Photo Album</h3>
            <div class="row">
                <div class="col-4">
                    <div class="card bg-light text-white" >
                        <img src="<?php echo e(asset("img/capture.png")); ?>" class="card-img" alt="..." id="imageInputBtn">
                        <div>
                            <form action="<?php echo e(url()->current()); ?>/add" method="post" enctype="multipart/form-data" id="photoUpload">
                            <?php echo csrf_field(); ?>
                            <input type="file" name="image" id="imageInput" onchange="document.getElementById('photoUpload').submit();">
                            <input type="submit" class="" hidden>
                            </form>
                        </div>
                    </div>
                </div>
                <?php while($i--): ?>
                <div class="col-4">
                    <div class="card bg-dark text-white">
                        <img src="<?php echo e(asset("images/2-jeeshan.jpeg")); ?>" class="card-img" alt="..." onclick="myFunction()">
                        <a href="<?php echo e(url()->current()); ?>/edit/<?php echo e($data[$i]->id); ?>" class="no-link-style" id="photoUrl">
                            <div class="card-img-overlay">
                                <form action="/builder/dashboard/photo-gallery/delete" method="post" id="deleteAlbumForm">
                                    <?php echo csrf_field(); ?>
                                <input type="text" value="album" name="type" hidden>
                                <input type="number" value="<?php echo e($data[$i]->id); ?>" name="id" hidden>
                                <input type="submt" value="<?php echo e($data[$i]->id); ?>" name="id" hidden>
                                <a type="submit" class="no-link-style" onclick="document.getElementById('deleteAlbumForm').submit()">
                                    <i class="fas fa-times"></i>
                                </a>
                                </form>
                            </div>
                        </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
    <div class="col-md-5 col-sm-12 web-view"></div>
</div>

<?php $__env->stopSection(); ?>

<script>
function myFunction() {
  document.getElementById("photoUrl").click(); // Click on the checkbox
}
</script>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views/builder/pages/photo/index.blade.php */ ?>