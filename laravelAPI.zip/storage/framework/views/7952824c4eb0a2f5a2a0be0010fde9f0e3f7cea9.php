<div class="card mb-3" style="max-width: 540px;">
    <div class="row no-gutters">
        <div class="col-md-4">
        <img src="<?php echo e(asset("images/".$data->image)); ?>" class="card-img h-100" alt="...">
        </div>
        <div class="col-md-8">
            <div class="card-body pb-2">
            <h5 class="card-title text-capitalize"><?php echo e($data->name); ?></h5>
                <div class="d-flex justify-content-sm-between">
                    <small class="text-capitalize">
                        <?php if($data->age != null || $data->age != 0): ?>
                            <?php echo e($data->age); ?>

                        <?php else: ?>
                            <?php echo e(__("Age")); ?>

                        <?php endif; ?>
                    </small>
                    <small class="text-capitalize">
                        <?php if($data->relation_name != null): ?>
                            <?php echo e($data->relation_name); ?>

                        <?php else: ?>
                            <?php echo e(__("Relation")); ?>

                        <?php endif; ?> 
                    </small>
                </div>
                <div class="d-flex justify-content-sm-between text-capitalize">
                    <small>
                        <?php if($data->profession != null || $data->profession != 0): ?>
                            <?php echo e($data->profession); ?>

                        <?php else: ?>
                            <?php echo e(__("Profession")); ?>

                        <?php endif; ?>
                    </small>
                    <small>
                        <?php if($data->maritial_status != null || $data->maritial_status != 0): ?>
                            <?php echo e($data->maritial_status); ?>

                        <?php else: ?>
                            <?php echo e(__("Maritial Status")); ?>

                        <?php endif; ?>
                    </small>
                </div>
                <div class="text-capitalize">
                    <small>
                        <?php if($data->about != null || $data->about != 0): ?>
                            <?php echo e($data->about); ?>

                        <?php else: ?>
                            <?php echo e(__("About")); ?>

                        <?php endif; ?>
                    </small>
                </div>
                <div class="row pt-4 d-flex justify-content-end">
                    <a href="<?php echo e(url()->current()); ?>/edit/<?php echo e($data->id); ?>" class="btn btn-submit">Edit</a>
                    <form action="<?php echo e(url()->current()); ?>/delete/<?php echo e($data->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="submit" class="btn btn-submit" value="Delete">
                    </form>
                </div>
            </div>
            
        </div>
    </div>
</div>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views/builder/pages/family/card.blade.php */ ?>