<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-7 col-sm-12 main-container about-info-edit">
        <div class="container-fluid">
            <h3 class="about-info-edit--heading text-uppercase mt-4">about couple</h3>

            <!-- Card Container -->
            <div class="row about-info-edit-card">

                <!-- Photo card -->
                <div class="col-md-5 col-sm-12">
                    <h5 class="mb-2">Groom</h5>
                    <div class="card bg-dark text-white" id="imageInputBtn">
                    <img src="<?php if($data->image != null || $data->image != ''): ?><?php echo e(asset('images/'.$data->image)); ?><?php else: ?><?php echo e(asset('img/capture.png')); ?><?php endif; ?>" class="card-img" alt="..." id="userImage">
                        <div class="card-img-overlay">
                           
                        </div>
                    </div> 
                </div>

                <!-- Form Subbmission -->
                <div class="col-md-7 col-sm-12">
                    <!-- <h5 class="mb-2">Bride</h5> -->
                    <form class="mt-5" method="POST" action="<?php echo e(url()->current()); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="text" class="form-control" id="formGroupExampleInput" name="full_name" placeholder="Full name" 
                            value="<?php echo e($data->name); ?>"
                            >
                        </div>
                        <div class="form-group">
                            <input type="number" class="form-control" id="formGroupExampleInput2" placeholder="Age" name="date" value="<?php echo e($data->age); ?>">
                        </div>
                        <div class="form-group">
                        <select type="text" class="form-control" id="formGroupExampleInput3" placeholder="Maritial Status" name="maritial_status" value="<?php echo e($data->maritial_status); ?>">
                                <option value="single">Single</option>
                                <option value="Married">Married</option>
                            </select>
                        </div>
                        <div class="form-group">
                        <input type="text" class="form-control" id="formGroupExampleInput4" placeholder="Profession" name="profession" value="<?php echo e($data->profession); ?>">
                        </div>
                        <div class="form-group">
                        <input type="text" class="form-control" id="formGroupExampleInput5" placeholder="Relation" name="relation" value="<?php echo e($data->relation_name); ?>">
                        <input type="text" class="form-control" name="bride_groom" value="<?php echo e($data->bride_groom); ?>" hidden>
                        </div>
                        <div class="form-group">
                        <textarea type="text" class="form-control" id="formGroupExampleInput6" placeholder="About" name="about" rows="5"><?php echo e($data->about); ?></textarea>
                        <input type="file" name="image" id="imageInput" style="display:none">
                        </div>
                        <div class="form-group">
                                <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn btn-cancel">Cancel <span class="text-uppercase"> x </span></button>
                            <button type="submit" class="btn btn-submit">Submit <span class="text-uppercase"> > </span></button>
                        </div>
                    </form>
                </div>
            </div>
            <!-- Card container ends -->
        </div>
    </div>
    <div class="col-md-5 col-sm-12 web-view"></div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views/builder/pages/family/family-edit.blade.php */ ?>