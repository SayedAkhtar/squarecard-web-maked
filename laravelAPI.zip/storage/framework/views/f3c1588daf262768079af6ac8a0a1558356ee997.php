<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Squarecaard- Info Edit</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/mobile.css">
</head>
<body>
<div class="row">
    <div class="col-md-7 col-sm-12 main-container dashboard">
        <div class="container-fluid">
            <div class="d-flex align-items-center justify-content-sm-between">
                <h3 class="dashboard--heading text-uppercase mt-4">Dashboard</h3>
                <div class="dashboard__head-buttons">
                    <a href="#" class="btn btn-secondary">Share 
                        <img src="img/share.png" alt="" class="img-responsive" height="16px">
                    </a>
                    <a href="#" class="btn btn-secondary">Help ?</a> 
                </div>
            </div><!-- Head Button Ended -->
            <div class="dashboard-main mt-3">
                <div class="dashboard_website-design">
                    <h6 class="text-uppercase">Website Design</h6>
                    <div class="d-flex flex-wrap">
                        <a href="#" class="btn btn-dashboard">
                            <img src="img/template.png" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Template</h6>
                        </a>
                        <a href="#" class="btn btn-dashboard ">
                            <img src="img/font-size.png" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Font</h6>
                        </a>
                    </div>
                </div>

                <div class="dashboard_wedding-details mt-3">
                    <h6 class="text-uppercase">Wedding Details</h6>
                    <div class="d-flex flex-wrap"> 
                        <a href="#" class="btn btn-dashboard">
                            <img src="img/information.png" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Basic Details</h6>
                        </a>
                        <a href="#" class="btn btn-dashboard ">
                            <img src="img/like.png" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Story</h6>
                        </a>
                        <a href="#" class="btn btn-dashboard">
                            <img src="img/clock.png" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Schedule</h6>
                        </a>
                        <a href="#" class="btn btn-dashboard ">
                            <img src="img/user.png" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Friends & Family</h6>
                        </a>
                        <a href="#" class="btn btn-dashboard">
                            <img src="img/relationship.png" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">About Couple</h6>
                        </a>
                        <a href="#" class="btn btn-dashboard ">
                            <img src="img/in.png" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Registry</h6>
                        </a>
                        <a href="#" class="btn btn-dashboard">
                            <img src="img/picture.png" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Photo Gallery</h6>
                        </a>
                        <a href="#" class="btn btn-dashboard ">
                            <img src="img/internet.png" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Other Services</h6>
                        </a>
                    </div>
                </div>

                <div class="dashboard_manage mt-3">
                    <h6 class="text-uppercase">Manage</h6>
                    <div class="d-flex">
                        <a href="#" class="btn btn-dashboard">
                            <img src="img/pros-and-cons.png" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">RSVP</h6>
                        </a>
                        <a href="#" class="btn btn-dashboard ">
                            <img src="img/settings.png" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Settings</h6>
                        </a>
                    </div>
                </div>
            </div>



        </div>
    </div>
    <div class="col-md-5 col-sm-12 web-view"></div>
</div>

    
<!-- Script -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views/builder/pages/dashboard.blade.php */ ?>