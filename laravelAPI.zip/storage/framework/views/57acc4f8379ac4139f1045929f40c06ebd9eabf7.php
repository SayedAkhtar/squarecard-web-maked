<?php $__env->startSection('content'); ?>
    
<?php
$id = Auth::user()->id;
?>
<div class="row">
    
    <div class="col-md-7 col-sm-12 main-container dashboard">
        <div class="container-fluid">
            <div class="d-flex align-items-center justify-content-sm-between">
                    <div class="action__button">
                        <div class="action__button--left">
                            
                            <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard"><img src="<?php echo e(asset('img/home.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                        </div>
                    </div>
                <h3 class="dashboard--heading text-uppercase mt-4">Dashboard</h3>
                <div class="dashboard__head-buttons">
                    <a href="#" class="btn btn-secondary">Share 
                        <img src="<?php echo e(asset("img/share.png")); ?>" alt="" class="img-responsive" height="16px">
                    </a>
                    <a class="btn btn-secondary" data-toggle="tooltip" data-placement="top" title="Under Development">Help ?</a> 
                </div>
            </div><!-- Head Button Ended -->
            <div class="dashboard-main mt-3">
                <div class="dashboard_website-design">
                    <h6 class="text-uppercase">Website Design</h6>
                    <div class="d-flex flex-wrap">
                        <a href="<?php echo e(url()->current()); ?>/template-edit" class="btn btn-dashboard">
                            <img src="<?php echo e(asset("img/template.png")); ?>" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Template</h6>
                        </a>
                        
                    </div>
                </div>

                <div class="dashboard_wedding-details mt-3">
                    <h6 class="text-uppercase">Wedding Details</h6>
                    <div class="d-flex flex-wrap"> 
                        <a href="<?php echo e(url()->current()); ?>/basic-details" class="btn btn-dashboard">
                            <img src="<?php echo e(asset("img/information.png")); ?>" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Basic Details</h6>
                        </a>
                        <a href="<?php echo e(url()->current()); ?>/story" class="btn btn-dashboard ">
                            <img src="<?php echo e(asset("img/like.png")); ?>" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Story</h6>
                        </a>
                        <a href="<?php echo e(url()->current()); ?>/schedule" class="btn btn-dashboard">
                            <img src="<?php echo e(asset("img/clock.png")); ?>" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Schedule</h6>
                        </a>
                        <a href="<?php echo e(url()->current()); ?>/family-details" class="btn btn-dashboard ">
                            <img src="<?php echo e(asset("img/user.png")); ?>" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Friends & Family</h6>
                        </a>
                        <a href="<?php echo e(url()->current()); ?>/about" class="btn btn-dashboard">
                            <img src="<?php echo e(asset("img/relationship.png")); ?>" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">About Couple</h6>
                        </a>
                        <a href="<?php echo e(url()->current()); ?>/registry" class="btn btn-dashboard ">
                            <img src="<?php echo e(asset("img/in.png")); ?>" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Registry</h6>
                        </a>
                        <a href="<?php echo e(url()->current()); ?>/photo-gallery" class="btn btn-dashboard">
                            <img src="<?php echo e(asset("img/picture.png")); ?>" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">Photo Gallery</h6>
                        </a>
                        
                    </div>
                </div>

                <div class="dashboard_manage mt-3">
                    <h6 class="text-uppercase">Manage</h6>
                    <div class="d-flex">
                        <a href="#<?php echo e(url()->current()); ?>/rsvp" class="btn btn-dashboard" data-toggle="tooltip" data-placement="top" title="Under Development">
                            <img src="<?php echo e(asset("img/pros-and-cons.png")); ?>" alt="" class="img-responsive">
                            <h6 class="dashboard--linkname">RSVP</h6>
                        </a>
                        
                    </div>
                </div>
                <div class="dashboard_manage mt-3">
                    <h6 class="text-uppercase"></h6>
                    <div class="d-flex">
                        <a class="btn btn-dashboard" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                             <img src="<?php echo e(asset("img/power.png")); ?>" alt="" class="img-responsive">
                             <h6 class="dashboard--linkname">logout</h6>
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
            </div>



        </div>
    </div>
    <div class="col-md-5 col-sm-12 web-view ">
        <?php echo $__env->make('builder.pages.iframe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views//builder/pages/dashboard.blade.php */ ?>