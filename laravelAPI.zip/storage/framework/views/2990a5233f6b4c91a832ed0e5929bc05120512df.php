<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-7 col-sm-12 about-main-container main-container">
        <div class="container-fluid">
                <div class="d-flex align-items-center justify-content-sm-between mb-3">
                        <div class="action__button">
                            <div class="action__button--left">
                                <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard" class="mr-3"><img src="<?php echo e(asset('img/back.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                                <a href="<?php echo e(env('APP_URL')); ?>/builder/dashboard"><img src="<?php echo e(asset('img/home.png')); ?>" alt="" class="img-responsive" height="30px"></a>
                            </div>
                        </div>
                    <h3 class="dashboard--heading text-uppercase mt-4">About Couple</h3>
                    <div class="dashboard__head-buttons">
                        <a href="#" class="btn btn-secondary">Share 
                            <img src="<?php echo e(asset("img/share.png")); ?>" alt="" class="img-responsive" height="16px">
                        </a>
                        <a href="#" class="btn btn-secondary">Help ?</a> 
                    </div>
                </div>

            <!-- Card Container -->
            <div class="row about-card">

                <!-- Groom card -->
                <div class="col-md-6 col-sm-12">
                    <h5 class="mb-2">Groom</h5>
                    <div class="card bg-dark text-white">
                        <a href="<?php echo e(url()->current()); ?>/edit/groom" style="color:inherit;">
                        <img src="<?php if($data->groom_image != null): ?><?php echo e(asset("images/".$data->groom_image)); ?><?php else: ?><?php echo e(asset('img/capture.png')); ?><?php endif; ?>" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <h2 class="card-title text-capitalize"><?php echo e($data->groom_name); ?></h2>
                            <p class="card-text text-capitalize"><?php echo e($data->groom_profession); ?></p>
                            <p class="card-text"><?php echo e($data->groom_dob); ?></p>
                        </div>
                        </a>
                    </div>
                </div>

                <!-- Bride card -->
                <div class="col-md-6 col-sm-12">
                    <h5 class="mb-2">Bride</h5>
                    <div class="card bg-dark text-light">
                        <a href="<?php echo e(url()->current()); ?>/edit/bride" style="color:inherit;">
                        <img src="<?php if($data->bride_image != null): ?><?php echo e(asset("images/".$data->bride_image)); ?><?php else: ?><?php echo e(asset('img/capture.png')); ?><?php endif; ?>" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <h2 class="card-title text-capitalize"><?php echo e($data->bride_name); ?></h2>
                            <p class="card-text text-capitalize"><?php echo e($data->bride_profession); ?></p>
                            <p class="card-text"><?php echo e($data->bride_dob); ?></p>
                        </div>
                        </a>
                    </div>
                </div>
            </div>
            <!-- Card container ends -->
        </div>
        
    </div>
    <div class="col-md-5 col-sm-12 web-view">
           <?php echo $__env->make('builder.pages.iframe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views/builder/pages/about-couple/index.blade.php */ ?>