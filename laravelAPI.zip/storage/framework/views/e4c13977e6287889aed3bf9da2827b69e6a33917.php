<?php

    $length = count($schedule);
    $length = 1;
?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-7 col-sm-12 main-container schedule">
        <div class="container-fluid">
            <h3 class="schedule--heading text-uppercase mt-4">Schedules</h3>

            <!-- Card Container -->
            <div class="row d-flex justify-content-center">
                <?php 
                while($length){
                    $length--;
                    $data = $schedule[$length];
                ?>
                <div class="card col-md-5 p-2 m-2" >
                    <img src="<?php echo e(asset("img/event.jpg")); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Event name</h5>
                        <div class="row d-flex justify-content-sm-between px-3 pb-2">
                            <small>
                                <?php echo e($data->event_start_date); ?> Time
                                 <span>
                                     <img src="<?php echo e(asset("img/calender.png")); ?>" alt="" class="img-responsive" height="20px">
                                </span>
                            </small>

                            <small>
                               <?php echo e($data->event_end_date); ?> Time
                                <span>
                                     <img src="<?php echo e(asset("img/calender.png")); ?>" alt="" class="img-responsive" height="20px">
                                </span>
                            </small>
                        </div>
                        <div class="row">
                            <div class="col-7">
                                <h4>Venue</h4>
                                <small class="text-capitalize"><?php echo e($data->event_venue); ?></small>
                                <!-- <small><button class="btn btn-secondary bg-secondary px-2 py-1 mx-0 mt-1 text-light">Find on Map</button></small> -->

                            </div>
                            <div class="col-5 schedule-map-container">
                                    
                            </div>

                        </div>
                        <h6 class="card-text mt-3"><?php echo e($data->event_short_description); ?></h6>
                        <a href="<?php echo e(url()->current()); ?>/edit/<?php echo e($data->id); ?>" class="btn btn-submit text-capitalize mx-0">change</a>
                        <a href="<?php echo e(url()->current()); ?>/delete/<?php echo e($data->id); ?>" class="btn btn-submit text-capitalize mx-0">delete</a>
                    </div>      
                </div> 
            <?php } ?>

            </div>
            <a href="#" class="btn btn-submit text-capitalize mx-auto my-3 d-block w-3">Add</a>             
    </div>
    <div class="col-md-5 col-sm-12 web-view"></div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('builder.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\ProjectFiles\laravelAPI\resources\views//builder/pages/schedule.blade.php */ ?>