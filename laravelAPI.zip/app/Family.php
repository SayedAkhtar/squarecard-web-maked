<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Symfony\Component\Console\Helper\Table;

class Family extends Model
{
    //
    protected $table ="family";
}
