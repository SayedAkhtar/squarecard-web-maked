<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WeddingRegister extends Model
{
    //
}
